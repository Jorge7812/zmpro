# SocksHttp (versão antiga)

Cliente ssh tunnel para Android.
