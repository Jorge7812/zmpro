package com.betlog.baho.model;

import android.view.View;

public interface OnUpdateLayout {
	void updateLayout(View view);
}
