package com.betlog.baho;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.zamworg.vpn.R;

public class edsongraphflip
{
	public edsongraphflip(MainActivity f,String str){
		Animation anim_in = AnimationUtils.loadAnimation(f, R.animator.pop_in);
		Animation anim_out = AnimationUtils.loadAnimation(f, R.animator.pop_out);
		if(str.contains("start")){
			f.graph_flip.startAnimation(anim_in);
			f.graph_flip.setVisibility(0);
			f.graph_flip.startAnimation(anim_in);
			f.image_flip.startAnimation(anim_out);
			f.image_flip.setVisibility(8);
		}else if(str.contains("stop")){
			f.image_flip.startAnimation(anim_in);
			f.image_flip.setVisibility(0);
			f.image_flip.startAnimation(anim_in);
			f.graph_flip.startAnimation(anim_out);
			f.graph_flip.setVisibility(8);
		}
	}
}
