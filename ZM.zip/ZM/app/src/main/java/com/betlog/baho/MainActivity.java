package com.betlog.baho;


import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.DialogFragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.betlog.baho.DrawerLog;
import com.betlog.baho.MainApp;
import com.betlog.baho.activities.BaseActivity;
import com.betlog.baho.activities.ConfigExportFileActivity;
import com.betlog.baho.activities.ConfigGeralActivity;
import com.betlog.baho.activities.ConfigImportFileActivity;
import com.betlog.baho.fragments.ClearConfigDialogFragment;
import com.betlog.baho.fragments.CustomSniFragments;
import com.betlog.baho.fragments.ProxyRemoteDialogFragment;
import com.betlog.baho.util.Utils;
import com.betlog.ultrasshservice.LaunchVpn;
import com.betlog.ultrasshservice.config.ConfigParser;
import com.betlog.ultrasshservice.config.Settings;
import com.betlog.ultrasshservice.logger.ConnectionStatus;
import com.betlog.ultrasshservice.logger.SkStatus;
import com.betlog.ultrasshservice.tunnel.TunnelManagerHelper;
import com.betlog.ultrasshservice.util.SkProtect;
import com.kervzcodes.payload.generator.ssh.PayloadGenerator;
import com.zamworg.vpn.R;
import java.io.IOException;
import android.support.design.widget.NavigationView;
import android.widget.RadioGroup;
import com.betlog.baho.util.VPNUtils;

import com.betlog.baho.Graph.GraphHelper;
import com.github.mikephil.charting.charts.LineChart;
import android.view.View.OnClickListener;
import java.util.List;
import com.betlog.baho.Graph.RetrieveData;
import com.betlog.baho.Graph.DataTransferGraph2;
import com.betlog.baho.Graph.StoredData;
import android.graphics.Color;

import android.net.TrafficStats;
import com.betlog.baho.activities.AboutActivity;
/**
 * Activity Principal
 * @author SlipkHunter
 */

/*public class MainActivity extends BaseActivity
implements DrawerLayout.DrawerListener,
			View.OnClickListener,CompoundButton.OnCheckedChangeListener, SkStatus.StateListener*/
public class MainActivity extends BaseActivity
implements DrawerLayout.DrawerListener,
NavigationView.OnNavigationItemSelectedListener,
View.OnClickListener, RadioGroup.OnCheckedChangeListener,
CompoundButton.OnCheckedChangeListener, SkStatus.StateListener,
DialogInterface.OnClickListener
{

	@Override
	public void onCheckedChanged(RadioGroup p1, int p2)
	{
		// TODO: Implement this method
	}
	
	@Override
	public boolean onNavigationItemSelected(MenuItem p1)
	{
		// TODO: Implement this method
		return false;
	}


	//public static void updateMainViews(Context context)
	{
		// TODO: Implement this method
	}

	@Override
	public void onClick(DialogInterface p1, int p2)
	{
		// TODO: Implement this method
	}
	
	
	
	private static final String TAG = MainActivity.class.getSimpleName();
	private static final String UPDATE_VIEWS = "MainUpdate";
	public static final String OPEN_LOGS = "com.slipkprojects.sockshttp:openLogs";
	private LinearLayout view_all_layout;
	private LinearLayout cmodsniLayout;
	private LinearLayout ViewGone;
	private TextView cmodsniText;
	private LinearLayout payload_menu;
	private DrawerLog mDrawer;
	private Settings mConfig;
	private Toolbar toolbar_main;
	private Handler mHandler;
	private LinearLayout mainLayout;
	private LinearLayout proxyInputLayout;
	private TextView proxyText;
	private android.support.v7.widget.CardView payloadLayout;
	private android.support.v7.widget.CardView cview;
	private TextInputEditText payloadEdit;
	private Switch customPayloadSwitch;
	private Button starterButton;
	private LinearLayout configMsgLayout;
	private TextView configMsgText;
	private RadioButton direct;
	private RadioButton ssh;
	private RadioButton ssl;
	private RadioButton sslpay;
	private RadioButton sslproxy;
	private RadioButton slowdns;
	private LinearLayout locker_type;
	
	private android.support.v7.widget.CardView card_graph;
	private Thread dataThread;
	public static View graph_flip;
	public static View image_flip;
	private LineChart mChart;
	private GraphHelper graph;
	private Handler fHandler = new Handler();
	private Thread dataUpdate;
	private TextView bytes_in, bytes_out;
	
	private Handler mHandler2 = new Handler();
	private long mStartRX = 0;
	private long mStartTX = 0;
	private final Runnable mRunnable = new Runnable() {
		public void run() {
			TextView RX = (TextView) findViewById(R.id.RX);
			TextView TX = (TextView) findViewById(R.id.TX);
			long resetdownload=TrafficStats.getTotalRxBytes();

			long rxBytes = TrafficStats.getTotalRxBytes() - mStartRX;

			RX.setText(Long.toString(rxBytes)+ " bytes");
			if (rxBytes >= 1024) {

				long rxKb = rxBytes / 1024;

				RX.setText(Long.toString(rxKb)+ " KB");
				if (rxKb >= 1024) {

					long rxMB = rxKb / 1024;

					RX.setText(Long.toString(rxMB)+ " MB");
					if (rxMB >= 1024) {

						long rxGB = rxMB / 1024;

						RX.setText(Long.toString(rxGB) + " GB");
					}
				}
			}

			mStartRX=resetdownload;

			long resetupload=TrafficStats.getTotalTxBytes();

			long txBytes = TrafficStats.getTotalTxBytes() - mStartTX;

			TX.setText(Long.toString(txBytes)+ " bytes");
			if (txBytes >= 1024) {

				long txKb = txBytes / 1024;

				TX.setText(Long.toString(txKb)+ " KB");
				if (txKb >= 1024) {

					long txMB = txKb / 1024;

					TX.setText(Long.toString(txMB)+ " MB");
					if (txMB >= 1024) {

						long txGB = txMB / 1024;

						TX.setText(Long.toString(txGB)+ " GB");
					}
				}
			}

			mStartTX=resetupload;

			mHandler2.postDelayed(mRunnable, 1000);
		}
	};
	
	
	public void flip(View v){
		if (image_flip.getVisibility() == 0) {
			new edsongraphflip(MainActivity.this, "start");
		}else{
			new edsongraphflip(MainActivity.this, "stop");
		}
	}

	@Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

		mHandler = new Handler();
		mConfig = new Settings(this);
		mDrawer = new DrawerLog(this);
		mStartRX = TrafficStats.getTotalRxBytes();
		mStartTX = TrafficStats.getTotalTxBytes();

		if (mStartRX == TrafficStats.UNSUPPORTED
			|| mStartTX == TrafficStats.UNSUPPORTED) {
			AlertDialog.Builder alert = new AlertDialog.Builder(this);
			alert.setTitle("Uh Oh!");
			alert.setMessage("Su dispositivo no es compatible con la supervisión de estadísticas de tráfico.");
			alert.show();

		} else {
			mHandler2.postDelayed(mRunnable, 1000);
		}
		
		
		SharedPreferences prefs = getSharedPreferences(MainApp.PREFS_GERAL, Context.MODE_PRIVATE);

		boolean showFirstTime = prefs.getBoolean("connect_first_time", true);
		int lastVersion = prefs.getInt("last_version", 0);

		// se primeira vez
		if (showFirstTime)
        {
            SharedPreferences.Editor pEdit = prefs.edit();
            pEdit.putBoolean("connect_first_time", false);
            pEdit.apply();

			Settings.setDefaultConfig(this);

			showBoasVindas();
        }

		try {
			int idAtual = ConfigParser.getBuildId(this);

			if (lastVersion < idAtual) {
				SharedPreferences.Editor pEdit = prefs.edit();
				pEdit.putInt("last_version", idAtual);
				pEdit.apply();

				// se estiver atualizando
				if (!showFirstTime) {
					if (lastVersion <= 12) {
						Settings.setDefaultConfig(this);
						Settings.clearSettings(this);

						Toast.makeText(this, "As configurações foram limpas para evitar bugs",
							Toast.LENGTH_LONG).show();
					}
				}

			}
		} catch(IOException e) {}
		
		
		// set layout
		doLayout();

		// verifica se existe algum problema
		SkProtect.CharlieProtect();

		// recebe local dados
		IntentFilter filter = new IntentFilter();
		filter.addAction(UPDATE_VIEWS);
		filter.addAction(OPEN_LOGS);
		
		LocalBroadcastManager.getInstance(this)
			.registerReceiver(mActivityReceiver, filter);
			
		doUpdateLayout();
	}
	
	
// Paygen here
	
	
	private void liveData()
	{
        dataUpdate = new Thread(new Runnable() {
				@Override
				public void run()
				{

					while (!dataUpdate.getName().equals("DETENIDO"))
					{

						fHandler.post(new Runnable() {

								//private static final long xup = 0;

								@Override
								public void run()
								{
									if(toString().equals("CONECTADO")){
										graph.start();
									}
								}
							});

						try
						{
							Thread.sleep(1000);
						}
						catch (InterruptedException e)
						{
							e.printStackTrace();
						}
						//  progressStatus--;
					}

				}
			});

        dataUpdate.setName("started");
        dataUpdate.start();
    }
	final class MyThreadClass implements Runnable{
        @Override
        public void run(){
            int i = 0;
            synchronized (this)
			{
                while (dataThread.getName() == "showDataGraph")
				{
                    //  Log.e("insidebroadcast", Integer.toString(service_id) + " " + Integer.toString(i));
                    getData2();
                    try
					{
                        wait(1000);
                        i++;
                    }
					catch (InterruptedException e)
					{
						// sshMsg(e.getMessage());
                    }

                }
				// stopSelf(service_id);
            }

        }
    }


	public void getData2(){
        List<Long> allData;
        allData = RetrieveData.findData();
		long mDownload = DataTransferGraph2.download;
		long mUpload = DataTransferGraph2.upload;
		mDownload = allData.get(0);
        mUpload = allData.get(1);
		storedData2(mUpload,mDownload);
    }

	public void storedData2(Long mUpload,Long mDownload){
        StoredData.downloadSpeed = mDownload;
        StoredData.uploadSpeed = mUpload;
        if (StoredData.isSetData){
            StoredData.downloadList.remove(0);
            StoredData.uploadList.remove(0);
            StoredData.downloadList.add(mDownload);
            StoredData.uploadList.add(mUpload);
        }
    }
	
	

	/**
	 * Layout
	 */
	 
	private void doLayout() {
		setContentView(R.layout.activity_main_drawer);

		toolbar_main = (Toolbar) findViewById(R.id.toolbar_main);
		
		setSupportActionBar(toolbar_main);
		mDrawer.setDrawer(this);
		mChart = (LineChart) findViewById(R.id.chart1);
		graph = GraphHelper.getHelper().with(this).color(Color.parseColor(getString(R.color.colorPrimary))).chart(mChart);
		if (!StoredData.isSetData)
		{
			StoredData.setZero();
		}

		liveData();
		
		setSupportActionBar(toolbar_main);
		mDrawer.setDrawer(this);
		mainLayout = (LinearLayout) findViewById(R.id.activity_mainLinearLayout);
		starterButton = (Button) findViewById(R.id.activity_starterButtonMain);
		proxyInputLayout = (LinearLayout) findViewById(R.id.activity_mainInputProxyLayout);
		proxyText = (TextView) findViewById(R.id.activity_mainProxyText);
		int permissionCheck = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
		if (permissionCheck != PackageManager.PERMISSION_GRANTED)
		{
			ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
		}
		direct = (RadioButton)findViewById(R.id.radio_direct);
		direct.setOnClickListener(this);
		ssh = (RadioButton)findViewById(R.id.radio_ssh);
		ssh.setOnClickListener(this);
		ssl = (RadioButton)findViewById(R.id.radio_ssl);
		ssl.setOnClickListener(this);
		sslpay = (RadioButton)findViewById(R.id.radio_sslpay);
		sslpay.setOnClickListener(this);
		sslproxy = (RadioButton)findViewById(R.id.radio_sslprox);
		sslproxy.setOnClickListener(this);
		slowdns = (RadioButton)findViewById(R.id.radio_slowdns);
		slowdns.setOnClickListener(this);
		
		
		
		card_graph  = (android.support.v7.widget.CardView)findViewById(R.id.card_graph);
		cview = (android.support.v7.widget.CardView)findViewById(R.id.cview);
		view_all_layout = (LinearLayout)findViewById(R.id.view_all_layout);
		payload_menu = (LinearLayout)findViewById(R.id.payload_menu);
		proxyInputLayout = (LinearLayout) findViewById(R.id.activity_mainInputProxyLayout);
		proxyText = (TextView) findViewById(R.id.activity_mainProxyText);
		ViewGone = (LinearLayout) findViewById(R.id.ViewGone);
		cmodsniLayout = (LinearLayout) findViewById(R.id.cmods_snilayout);
		cmodsniText = (TextView) findViewById(R.id.cmods_snitext);
		cmodsniText.setText(mConfig.getPrivString(Settings.CUSTOM_SNI));
		cmodsniLayout.setOnClickListener(new OnClickListener(){
				SharedPreferences prefs = mConfig.getPrefsPrivate();
				@Override
				public void onClick(View p1) {
					if (!prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
						doSaveData();

						DialogFragment fragSni = new CustomSniFragments();
						fragSni.show(getSupportFragmentManager(), "customSni");
					}
				}
			});
		
		customPayloadSwitch = (Switch) findViewById(R.id.activity_mainCustomPayloadSwitch);
		locker_type = (LinearLayout)findViewById(R.id.locker_type);
		starterButton.setOnClickListener(this);
		proxyInputLayout.setOnClickListener(this);

		payloadLayout = (android.support.v7.widget.CardView) findViewById(R.id.activity_mainInputPayloadLinearLayout);
		payloadEdit = (TextInputEditText) findViewById(R.id.activity_mainInputPayloadEditText);

		configMsgLayout = (LinearLayout) findViewById(R.id.activity_mainMensagemConfigLinearLayout);
		configMsgText = (TextView) findViewById(R.id.activity_mainMensagemConfigTextView);

		// fix bugs
		if (mConfig.getPrefsPrivate().getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
		}
		else {
			payloadEdit.setText(mConfig.getPrivString(Settings.CUSTOM_PAYLOAD_KEY));
		}

		
		customPayloadSwitch.setOnCheckedChangeListener(this);
		
		
		
	}
	
	private void doUpdateLayout() {
		SharedPreferences prefs = mConfig.getPrefsPrivate();

		boolean isRunning = SkStatus.isTunnelActive();
		int tunnelType = prefs.getInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_DIRECT);
		
		setStarterButton(starterButton, this);
		setPayloadSwitch(tunnelType, !prefs.getBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true));

		String proxyStr = getText(R.string.def_value).toString();

		if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			proxyStr = "Locked";
			proxyInputLayout.setEnabled(false);
			customPayloadSwitch.setEnabled(false);
			payloadLayout.setVisibility(View.VISIBLE);
			payloadLayout.setEnabled(false);
			payloadEdit.setText("Locked");
			locker_type.setEnabled(false);
			direct.setEnabled(false);
			ssh.setEnabled(false);
			ssl.setEnabled(false);
			sslpay.setEnabled(false);
			sslproxy.setEnabled(false);
			slowdns.setEnabled(false);
		}
		else {
			String proxy = mConfig.getPrivString(Settings.PROXY_IP_KEY);

			if (proxy != null && !proxy.isEmpty())
				proxyStr = String.format("%s:%s", proxy, mConfig.getPrivString(Settings.PROXY_PORTA_KEY));
			proxyInputLayout.setEnabled(!isRunning);
		} 

		proxyText.setText(proxyStr);
		String sniStr = getText(R.string.ssl_value).toString();


		if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			sniStr = "Locked";
			cmodsniLayout.setEnabled(false);
			payloadLayout.setVisibility(View.VISIBLE);
			payloadLayout.setEnabled(false);
			customPayloadSwitch.setEnabled(false);
			payloadEdit.setText("Locked");
			locker_type.setEnabled(false);
			direct.setEnabled(false);
			ssh.setEnabled(false);
			ssl.setEnabled(false);
			sslpay.setEnabled(false);
			sslproxy.setEnabled(false);
			slowdns.setEnabled(false);
		}
		else {
			String sni = mConfig.getPrivString(Settings.CUSTOM_SNI);

			if (sni != null && !sni.isEmpty())
				sniStr = String.format(mConfig.getPrivString(Settings.CUSTOM_SNI));
			cmodsniLayout.setEnabled(!isRunning);
		} 

		cmodsniText.setText(sniStr);
		
		SharedPreferences.Editor edit = mConfig.getPrefsPrivate().edit();
		switch (tunnelType)
		{
			case Settings.bTUNNEL_TYPE_SSH_DIRECT:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_DIRECT);
				proxyInputLayout.setVisibility(View.GONE);
				payloadLayout.setVisibility(View.VISIBLE);
				ViewGone.setVisibility(View.GONE);
				cmodsniLayout.setVisibility(View.GONE);
				customPayloadSwitch.setClickable(true);
				payload_menu.setVisibility(View.VISIBLE);
				customPayloadSwitch.setVisibility(View.VISIBLE);
				view_all_layout.setVisibility(View.VISIBLE);
				cview.setVisibility(View.VISIBLE);
				direct.setChecked(true);
				ssh.setChecked(false);
				ssl.setChecked(false);
				sslpay.setChecked(false);
				sslproxy.setChecked(false);
				slowdns.setChecked(false);
				break;

			case Settings.bTUNNEL_TYPE_SSH_PROXY:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_PROXY);
				proxyInputLayout.setVisibility(View.VISIBLE);
				payloadLayout.setVisibility(View.VISIBLE);
				ViewGone.setVisibility(View.GONE);
				cmodsniLayout.setVisibility(View.GONE);
				customPayloadSwitch.setClickable(true);
				payload_menu.setVisibility(View.VISIBLE);
				customPayloadSwitch.setVisibility(View.VISIBLE);
				view_all_layout.setVisibility(View.VISIBLE);
				cview.setVisibility(View.VISIBLE);
				direct.setChecked(false);
				ssh.setChecked(true);
				ssl.setChecked(false);
				sslpay.setChecked(false);
				sslproxy.setChecked(false);
				slowdns.setChecked(false);
				break;
			case Settings.bTUNNEL_TYPE_SSL_PROXY:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSL_PROXY);
				edit.putBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true).apply();
				customPayloadSwitch.setClickable(false);
				customPayloadSwitch.setChecked(false);
				proxyInputLayout.setVisibility(View.GONE);
				payloadLayout.setVisibility(View.VISIBLE);
				ViewGone.setVisibility(View.VISIBLE);
				payload_menu.setVisibility(View.GONE);
				cmodsniLayout.setVisibility(View.VISIBLE);
				customPayloadSwitch.setVisibility(View.GONE);
				view_all_layout.setVisibility(View.VISIBLE);
				cview.setVisibility(View.GONE);
				direct.setChecked(false);
				ssh.setChecked(false);
				ssl.setChecked(true);
				sslpay.setChecked(false);
				sslproxy.setChecked(false);
				slowdns.setChecked(false);
				break;
			case Settings.bTUNNEL_TYPE_PAY_SSL:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_PAY_SSL);
				proxyInputLayout.setVisibility(View.GONE);
				payloadLayout.setVisibility(View.VISIBLE);
				ViewGone.setVisibility(View.VISIBLE);
				cmodsniLayout.setVisibility(View.VISIBLE);
				payload_menu.setVisibility(View.VISIBLE);
				customPayloadSwitch.setClickable(true);
				customPayloadSwitch.setVisibility(View.VISIBLE);
				view_all_layout.setVisibility(View.VISIBLE);
				cview.setVisibility(View.VISIBLE);
				direct.setChecked(false);
				ssh.setChecked(false);
				ssl.setChecked(false);
				sslpay.setChecked(true);
				sslproxy.setChecked(false);
				slowdns.setChecked(false);
				break;

			case Settings.bTUNNEL_TYPE_SLOWDNS:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SLOWDNS);
				proxyInputLayout.setVisibility(View.GONE);
				payloadLayout.setVisibility(View.GONE);
				ViewGone.setVisibility(View.GONE);
				cmodsniLayout.setVisibility(View.GONE);
				payload_menu.setVisibility(View.GONE);
				customPayloadSwitch.setClickable(false);
				customPayloadSwitch.setVisibility(View.GONE);
				view_all_layout.setVisibility(View.GONE);
				cview.setVisibility(View.GONE);
				direct.setChecked(false);
				ssh.setChecked(false);
				ssl.setChecked(false);
				sslpay.setChecked(false);
				sslproxy.setChecked(false);
				slowdns.setChecked(true);
				break;

			case Settings.bTUNNEL_TYPE_SSL_RP:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSL_RP);
				proxyInputLayout.setVisibility(View.VISIBLE);
				payloadLayout.setVisibility(View.VISIBLE);
				ViewGone.setVisibility(View.VISIBLE);
				cmodsniLayout.setVisibility(View.VISIBLE);
				payload_menu.setVisibility(View.VISIBLE);
				view_all_layout.setVisibility(View.VISIBLE);
				customPayloadSwitch.setClickable(true);
				customPayloadSwitch.setVisibility(View.VISIBLE);
				cview.setVisibility(View.VISIBLE);
				direct.setChecked(false);
				ssh.setChecked(false);
				ssl.setChecked(false);
				sslpay.setChecked(false);
				sslproxy.setChecked(true);
				slowdns.setChecked(false);
				break;
		}
		

		int msgVisibility = View.GONE;
		String msgText = "";
		boolean enabled_radio = !isRunning;

		if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			
			
			String msg = mConfig.getPrivString(Settings.CONFIG_MENSAGEM_KEY);
			if (!msg.isEmpty()) {
				msgText = msg.replace("\n", "<br/>");
				msgVisibility = View.VISIBLE;
			}
			
			if (mConfig.getPrivString(Settings.PROXY_IP_KEY).isEmpty() ||
					mConfig.getPrivString(Settings.PROXY_PORTA_KEY).isEmpty()) {
				enabled_radio = false;
			}
		}

		
		configMsgText.setText(msgText.isEmpty() ? "" : Html.fromHtml(msgText));
		configMsgLayout.setVisibility(msgVisibility);
		
		
	}
	
	
	private synchronized void doSaveData() {
		SharedPreferences prefs = mConfig.getPrefsPrivate();
		SharedPreferences.Editor edit = prefs.edit();

		if (mainLayout != null && !isFinishing())
			mainLayout.requestFocus();
		
		if (!prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			if (payloadEdit != null && !prefs.getBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true)) {
				edit.putString(Settings.CUSTOM_PAYLOAD_KEY, payloadEdit.getText().toString());
			}
		}
		else {
			
		}

		edit.apply();
	}


	/**
	 * Tunnel SSH
	 */

	public void startOrStopTunnel(Activity activity) {
		if (SkStatus.isTunnelActive()) {
			TunnelManagerHelper.stopSocksHttp(activity);
		}
		else {
			// oculta teclado se vísivel, tá com bug, tela verde
			//Utils.hideKeyboard(activity);
			
			Settings config = new Settings(activity);
			
			Intent intent = new Intent(activity, LaunchVpn.class);
			intent.setAction(Intent.ACTION_MAIN);
			
			if (config.getHideLog()) {
				intent.putExtra(LaunchVpn.EXTRA_HIDELOG, true);
			}
			
			activity.startActivity(intent);
		}
	}

	private void setPayloadSwitch(int tunnelType, boolean isCustomPayload) {
		SharedPreferences prefs = mConfig.getPrefsPrivate();

		boolean isRunning = SkStatus.isTunnelActive();

		customPayloadSwitch.setChecked(isCustomPayload);

		if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			payloadEdit.setEnabled(false);
			
			if (mConfig.getPrivString(Settings.CUSTOM_PAYLOAD_KEY).isEmpty()) {
				customPayloadSwitch.setEnabled(false);
			}
			else {
				customPayloadSwitch.setEnabled(!isRunning);
			}
			
			if (!isCustomPayload && tunnelType == Settings.bTUNNEL_TYPE_SSH_PROXY)
				payloadEdit.setText(Settings.PAYLOAD_DEFAULT);
			else
				payloadEdit.setText("*******");
		}
		else {
			customPayloadSwitch.setEnabled(!isRunning);

			if (isCustomPayload) {
				payloadEdit.setText(mConfig.getPrivString(Settings.CUSTOM_PAYLOAD_KEY));
				payloadEdit.setEnabled(!isRunning);
			}
			else if (tunnelType == Settings.bTUNNEL_TYPE_SSH_PROXY) {
				payloadEdit.setText(Settings.PAYLOAD_DEFAULT);
				payloadEdit.setEnabled(false);
			}else if (tunnelType == Settings.bTUNNEL_TYPE_SSH_DIRECT) {
				payloadEdit.setText(Settings.PAYLOAD_DEFAULT);
				payloadEdit.setEnabled(false);
			}else if (tunnelType == Settings.bTUNNEL_TYPE_PAY_SSL) {
				payloadEdit.setText(Settings.PAYLOAD_DEFAULT);
				payloadEdit.setEnabled(false);
			}else if (tunnelType == Settings.bTUNNEL_TYPE_SSL_RP) {
				payloadEdit.setText(Settings.PAYLOAD_DEFAULT);
				payloadEdit.setEnabled(false);
			}
		}

		if (isCustomPayload || tunnelType == Settings.bTUNNEL_TYPE_SSH_PROXY) {
			payloadLayout.setVisibility(View.VISIBLE);
		} else if (isCustomPayload || tunnelType == Settings.bTUNNEL_TYPE_SSH_DIRECT) {
			payloadLayout.setVisibility(View.VISIBLE);
		} else if (isCustomPayload || tunnelType == Settings.bTUNNEL_TYPE_SSL_RP) {
			payloadLayout.setVisibility(View.VISIBLE);
		} else if (isCustomPayload || tunnelType == Settings.bTUNNEL_TYPE_PAY_SSL) {
			payloadLayout.setVisibility(View.VISIBLE);
		}
		else {
			payloadLayout.setVisibility(View.GONE);
		}
	}

	public void setStarterButton(Button starterButton, Activity activity) {
		String state = SkStatus.getLastState();
		boolean isRunning = SkStatus.isTunnelActive();

		if (starterButton != null) {
			int resId;
			
			SharedPreferences prefsPrivate = new Settings(activity).getPrefsPrivate();

			if (ConfigParser.isValidadeExpirou(prefsPrivate
					.getLong(Settings.CONFIG_VALIDADE_KEY, 0))) {
				resId = R.string.expired;
				starterButton.setEnabled(false);

				if (isRunning) {
					startOrStopTunnel(activity);
				}
			}
			else if (prefsPrivate.getBoolean(Settings.BLOQUEAR_ROOT_KEY, false) &&
					ConfigParser.isDeviceRooted(activity)) {
			   resId = R.string.blocked;
			   starterButton.setEnabled(false);
			   
			   Toast.makeText(activity, R.string.error_root_detected, Toast.LENGTH_SHORT)
					.show();

			   if (isRunning) {
				   startOrStopTunnel(activity);
			   }
			}
			else if (SkStatus.SSH_INICIANDO.equals(state)) {
				resId = R.string.stop;
				dataThread = new Thread(new MyThreadClass());
				//new edsongraphflip(SocksHttpMainActivity.this, "start");
				dataThread.setName("showDataGraph");
				dataThread.start();
				starterButton.setEnabled(false);
				graph.start();
				card_graph.setVisibility(View.VISIBLE);
			}
			else if (SkStatus.SSH_PARANDO.equals(state)) {
				resId = R.string.state_stopping;
				//starterButton.setEnabled(false);
				dataThread = new Thread(new MyThreadClass());
				dataThread.setName("stopDataGraph");
				starterButton.setEnabled(false);
				card_graph.setVisibility(View.GONE);
				//graph.stop();
			}
			else {
				resId = isRunning ? R.string.stop : R.string.start;
				starterButton.setEnabled(true);
			}

			starterButton.setText(resId);
		}
	}
	

	
	@Override
    public void onPostCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onPostCreate(savedInstanceState, persistentState);
        
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        
    }
	
	private boolean isMostrarSenha = false;
	
	@Override
	public void onClick(View p1)
	{
		SharedPreferences prefs = mConfig.getPrefsPrivate();
		SharedPreferences.Editor edit = mConfig.getPrefsPrivate().edit();
		switch (p1.getId()) {
			case R.id.activity_starterButtonMain:
				doSaveData();
				startOrStopTunnel(this);
				//doSavez();
				if(SkStatus.isTunnelActive())
				{
					direct.setEnabled(true);
					ssh.setEnabled(true);
					ssl.setEnabled(true);
					sslpay.setEnabled(true);
					sslproxy.setEnabled(true);
					slowdns.setEnabled(true);
				} else {
					direct.setEnabled(false);
					ssh.setEnabled(false);
					ssl.setEnabled(false);
					sslpay.setEnabled(false);
					sslproxy.setEnabled(false);
					slowdns.setEnabled(false);
				}
				
				break;

			case R.id.activity_mainInputProxyLayout:
				if (!prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
					doSaveData();

					DialogFragment fragProxy = new ProxyRemoteDialogFragment();
					fragProxy.show(getSupportFragmentManager(), "proxyDialog");
				}
				break;
				
			case R.id.radio_direct:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_DIRECT);
				proxyInputLayout.setVisibility(View.GONE);
				payloadLayout.setVisibility(View.VISIBLE);
				ViewGone.setVisibility(View.GONE);
				cmodsniLayout.setVisibility(View.GONE);
				customPayloadSwitch.setClickable(true);
				payload_menu.setVisibility(View.VISIBLE);
				customPayloadSwitch.setVisibility(View.VISIBLE);
				view_all_layout.setVisibility(View.VISIBLE);
				direct.setChecked(true);
				ssh.setChecked(false);
				ssl.setChecked(false);
				sslpay.setChecked(false);
				sslproxy.setChecked(false);
				slowdns.setChecked(false);
				break;

			case R.id.radio_ssh:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_PROXY);
				proxyInputLayout.setVisibility(View.VISIBLE);
				payloadLayout.setVisibility(View.VISIBLE);
				ViewGone.setVisibility(View.GONE);
				cmodsniLayout.setVisibility(View.GONE);
				customPayloadSwitch.setClickable(true);
				payload_menu.setVisibility(View.VISIBLE);
				customPayloadSwitch.setVisibility(View.VISIBLE);
				view_all_layout.setVisibility(View.VISIBLE);
				direct.setChecked(false);
				ssh.setChecked(true);
				ssl.setChecked(false);
				sslpay.setChecked(false);
				sslproxy.setChecked(false);
				slowdns.setChecked(false);
				break;
			case R.id.radio_ssl:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSL_PROXY);
				edit.putBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true).apply();
				customPayloadSwitch.setClickable(false);
				customPayloadSwitch.setChecked(false);
				proxyInputLayout.setVisibility(View.GONE);
				payloadLayout.setVisibility(View.VISIBLE);
				ViewGone.setVisibility(View.VISIBLE);
				payload_menu.setVisibility(View.GONE);
				cmodsniLayout.setVisibility(View.VISIBLE);
				customPayloadSwitch.setVisibility(View.GONE);
				view_all_layout.setVisibility(View.VISIBLE);
				direct.setChecked(false);
				ssh.setChecked(false);
				ssl.setChecked(true);
				sslpay.setChecked(false);
				sslproxy.setChecked(false);
				slowdns.setChecked(false);
				break;
			case R.id.radio_sslpay:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_PAY_SSL);
				proxyInputLayout.setVisibility(View.GONE);
				payloadLayout.setVisibility(View.VISIBLE);
				ViewGone.setVisibility(View.VISIBLE);
				cmodsniLayout.setVisibility(View.VISIBLE);
				payload_menu.setVisibility(View.VISIBLE);
				customPayloadSwitch.setClickable(true);
				customPayloadSwitch.setVisibility(View.VISIBLE);
				view_all_layout.setVisibility(View.VISIBLE);
				direct.setChecked(false);
				ssh.setChecked(false);
				ssl.setChecked(false);
				sslpay.setChecked(true);
				sslproxy.setChecked(false);
				slowdns.setChecked(false);
				break;

			case R.id.radio_slowdns:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SLOWDNS);
				proxyInputLayout.setVisibility(View.GONE);
				payloadLayout.setVisibility(View.GONE);
				ViewGone.setVisibility(View.GONE);
				cmodsniLayout.setVisibility(View.GONE);
				payload_menu.setVisibility(View.GONE);
				customPayloadSwitch.setClickable(false);
				customPayloadSwitch.setVisibility(View.GONE);
				view_all_layout.setVisibility(View.GONE);
				direct.setChecked(false);
				ssh.setChecked(false);
				ssl.setChecked(false);
				sslpay.setChecked(false);
				sslproxy.setChecked(false);
				slowdns.setChecked(true);
				break;

			case R.id.radio_sslprox:
				edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSL_RP);
				proxyInputLayout.setVisibility(View.VISIBLE);
				payloadLayout.setVisibility(View.VISIBLE);
				ViewGone.setVisibility(View.VISIBLE);
				cmodsniLayout.setVisibility(View.VISIBLE);
				payload_menu.setVisibility(View.VISIBLE);
				view_all_layout.setVisibility(View.VISIBLE);
				customPayloadSwitch.setClickable(true);
				customPayloadSwitch.setVisibility(View.VISIBLE);
				direct.setChecked(false);
				ssh.setChecked(false);
				ssl.setChecked(false);
				sslpay.setChecked(false);
				sslproxy.setChecked(true);
				slowdns.setChecked(false);
				break;
		}
		edit.apply();

		doSaveData();
		doUpdateLayout();
	}

	
	@Override
	public void onCheckedChanged(CompoundButton p1, boolean p2)
	{
		SharedPreferences prefs = mConfig.getPrefsPrivate();
		SharedPreferences.Editor edit = prefs.edit();

		switch (p1.getId()) {
			case R.id.activity_mainCustomPayloadSwitch:
				edit.putBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, !p2);
				setPayloadSwitch(prefs.getInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_DIRECT), p2);
				break;
		}

		edit.apply();

		doSaveData();
	}
	
	protected void showBoasVindas() {
		new AlertDialog.Builder(this)
            . setTitle(R.string.attention)
            . setMessage(R.string.first_start_msg)
			. setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface di, int p) {
					// ok
				}
			})
			. setCancelable(false)
            . show();
	}
	
	@Override
	public void updateState(final String state, String msg, int localizedResId, final ConnectionStatus level, Intent intent)
	{
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				doUpdateLayout();
			}
		});
		
		switch (state) {
			case SkStatus.SSH_CONECTADO:
				
			break;
		}
	}


	/**
	 * Recebe locais Broadcast
	 */

	private BroadcastReceiver mActivityReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action == null)
                return;

            if (action.equals(UPDATE_VIEWS) && !isFinishing()) {
				doUpdateLayout();
			}
			else if (action.equals(OPEN_LOGS)) {
				if (mDrawer != null && !isFinishing()) {
					DrawerLayout drawerLayout = mDrawer.getDrawerLayout();
					
					if (!drawerLayout.isDrawerOpen(GravityCompat.END)) {
						drawerLayout.openDrawer(GravityCompat.END);
					}
				}
			}
        }
    };


	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		

		// Menu Itens
		switch (item.getItemId()) {

			case R.id.miLimparConfig:
				if (!SkStatus.isTunnelActive()) {
					DialogFragment dialog = new ClearConfigDialogFragment();
					dialog.show(getSupportFragmentManager(), "alertClearConf");
				} else {
					Toast.makeText(this, R.string.error_tunnel_service_execution, Toast.LENGTH_SHORT)
						.show();
				}
				break;
			case R.id.payloadGenerator:
				showPayloadGenerator();
				break;
			case R.id.miSettings:
				Intent intentSettings = new Intent(this, ConfigGeralActivity.class);
				//intentSettings.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(intentSettings);
				break;
				
			case R.id.mabout:
				Intent intentAbout = new Intent(this, AboutActivity.class);
				//intentSettings.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(intentAbout);
				break;
				
			
				
			case R.id.miSettingImportar:
				if (SkStatus.isTunnelActive()) {
					Toast.makeText(this, R.string.error_tunnel_service_execution,
						Toast.LENGTH_SHORT).show();
				}
				else {
					Intent intentImport = new Intent(this, ConfigImportFileActivity.class);
					startActivity(intentImport);
				}
				break;

			case R.id.miSettingExportar:
				SharedPreferences prefs = mConfig.getPrefsPrivate();
				
				if (SkStatus.isTunnelActive()) {
					Toast.makeText(this, R.string.error_tunnel_service_execution,
						Toast.LENGTH_SHORT).show();
				}
				else if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
					Toast.makeText(this, R.string.error_settings_blocked,
						Toast.LENGTH_SHORT).show();
				}
				else {
					Intent intentExport = new Intent(this, ConfigExportFileActivity.class);
					startActivity(intentExport);
				}
				break;
				
			case R.id.hardware:
				AlertDialog.Builder mBuilder = new AlertDialog.Builder(MainActivity.this);
				mBuilder.setTitle("TOKEN ID");
				mBuilder.setMessage(VPNUtils.getHWID());
				mBuilder.setCancelable(false);
				mBuilder.setPositiveButton("COPIAR", new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface mDialogInterface, int mInt)
						{
							((ClipboardManager)getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("HWID", VPNUtils.getHWID()));
						}
					});
				mBuilder.setNeutralButton("CANCELAR", new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface mDialog, int mInt)
						{
							mDialog.cancel();
						}
					});
				mBuilder.show();
				//drawerLayout.closeDrawers();
				

				// logs opções
			case R.id.miLimparLogs:
				mDrawer.clearLogs();
			break;
			
			case R.id.miExit:
				if (Build.VERSION.SDK_INT >= 16) {
					finishAffinity();
				}
				
				System.exit(0);
			break;
		}

		return super.onOptionsItemSelected(item);
	}
	
	private void showPayloadGenerator() {
		PayloadGenerator payloadGenerator = new PayloadGenerator(this);
		payloadGenerator.setDialogTitle("PAYLOAD GEN");
		payloadGenerator.setGenerateListener("GUARDAR", new PayloadGenerator.OnGenerateListener() {
				@Override
				public void onGenerate(String payloadGenerated) {
					payloadEdit.setText(payloadGenerated);
				}
			});
		payloadGenerator.show();
	}

	@Override
	public void onBackPressed() {
		
			showExitDialog();
	}

	
	
	@Override
    public void onResume() {
        super.onResume();

		mDrawer.onResume();
		
		SkStatus.addStateListener(this);

    }

	@Override
	protected void onPause()
	{
		super.onPause();
		
		doSaveData();
		
		SkStatus.removeStateListener(this);
		
		
	}

	@Override
	protected void onDestroy()
	{
		super.onDestroy();
		
		mDrawer.onDestroy();

		LocalBroadcastManager.getInstance(this)
			.unregisterReceiver(mActivityReceiver);
			
		
	}


	/**
	 * DrawerLayout Listener
	 */

	@Override
	public void onDrawerOpened(View view) {
		if (view.getId() == R.id.activity_mainLogsDrawerLinear) {
			toolbar_main.getMenu().clear();
			getMenuInflater().inflate(R.menu.logs_menu, toolbar_main.getMenu());
		}
	}

	@Override
	public void onDrawerClosed(View view) {
		if (view.getId() == R.id.activity_mainLogsDrawerLinear) {
			toolbar_main.getMenu().clear();
			getMenuInflater().inflate(R.menu.main_menu, toolbar_main.getMenu());
		}
	}

	@Override
	public void onDrawerStateChanged(int stateId) {}
	@Override
	public void onDrawerSlide(View view, float p2) {}

	
	/**
	 * Utils
	 */

	public static void updateMainViews(Context context) {
		Intent updateView = new Intent(UPDATE_VIEWS);
		LocalBroadcastManager.getInstance(context)
			.sendBroadcast(updateView);
	}
	
	public void showExitDialog() {
		AlertDialog dialog = new AlertDialog.Builder(this).
			create();
		dialog.setTitle(getString(R.string.attention));
		dialog.setMessage(getString(R.string.alert_exit));

		dialog.setButton(DialogInterface.BUTTON_POSITIVE, getString(R.
				string.exit),
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which)
				{
					Utils.exitAll(MainActivity.this);
				}
			}
		);

		dialog.setButton(DialogInterface.BUTTON_NEGATIVE, getString(R.
				string.minimize),
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// minimiza app
					Intent startMain = new Intent(Intent.ACTION_MAIN);
					startMain.addCategory(Intent.CATEGORY_HOME);
					startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(startMain);
				}
			}
		);

		dialog.show();
	}
}

